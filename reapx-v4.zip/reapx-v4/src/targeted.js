/**
 * ReapX v4.0 — by ReapFX
 * @author  ReapFX <https://github.com/ReapFX>
 * @copyright 2025 ReapFX. All rights reserved.
 * This code is proprietary. Do not copy, distribute, or reuse without written permission from ReapFX.
 */
import { config } from './config.js';
import { logger } from './logger.js';

export function checkTargetMatch({ name = '', symbol = '', creator = '' }) {
  const normName    = name.trim().toUpperCase();
  const normSymbol  = symbol.trim().toUpperCase().replace('$', '');
  const normCreator = creator.trim();

  for (const target of config.nameSnipeTargets) {
    if (normName === target) {
      logger.info({ name, target }, `🎯 Exact name match: "${name}"`);
      return { matched: true, type: 'name', reason: `Name match: "${name}"` };
    }
  }
  for (const target of config.tickerSnipeTargets) {
    if (normSymbol === target) {
      logger.info({ symbol, target }, `🎯 Exact ticker match: $${symbol}`);
      return { matched: true, type: 'ticker', reason: `Ticker match: $${symbol}` };
    }
  }
  for (const wallet of config.devWalletTargets) {
    if (normCreator === wallet) {
      logger.info({ creator, wallet }, `🎯 Dev wallet match: ${creator.slice(0,8)}...`);
      return { matched: true, type: 'dev', reason: `Dev wallet: ${creator.slice(0,8)}...` };
    }
  }
  return { matched: false, type: null, reason: '' };
}

export function logTargetSummary() {
  if (!config.hasTargetedMode && !config.kolCopyEnabled) return;
  logger.info('─────────────────────────────────────────');
  logger.info('🎯 Targeted Snipe Mode ACTIVE');
  if (config.nameSnipeTargets.length)   logger.info(`  Names  : ${config.nameSnipeTargets.join(', ')}`);
  if (config.tickerSnipeTargets.length) logger.info(`  Tickers: ${config.tickerSnipeTargets.map(t=>'$'+t).join(', ')}`);
  if (config.devWalletTargets.length)   logger.info(`  Dev wallets: ${config.devWalletTargets.length} tracked`);
  if (config.kolCopyEnabled)            logger.info(`  KOL wallets: ${config.kolWallets.length} copy-trade`);
  logger.info('─────────────────────────────────────────');
}

export default { checkTargetMatch, logTargetSummary };

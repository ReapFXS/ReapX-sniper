/**
 * ReapX v4.0 — by ReapFX
 * @author  ReapFX <https://github.com/ReapFX>
 * @copyright 2025 ReapFX. All rights reserved.
 * This code is proprietary. Do not copy, distribute, or reuse without written permission from ReapFX.
 */
import { PublicKey } from '@solana/web3.js';
import { logger } from './logger.js';
import { getRpcPool } from './rpc.js';

export async function analyzeHolders(mintAddress, creatorAddress) {
  try {
    const conn = getRpcPool().primary;
    const mint = new PublicKey(mintAddress);

    const { value: holders } = await conn.getTokenLargestAccounts(mint);
    if (!holders || holders.length === 0) {
      return { topHoldersPct: 0, devHolderPct: 0, bundleDetected: false, holderCount: 0 };
    }

    const mintInfo = await conn.getParsedAccountInfo(mint);
    const supplyRaw = mintInfo.value?.data?.parsed?.info?.supply;
    const decimals  = mintInfo.value?.data?.parsed?.info?.decimals ?? 6;
    const totalSupply = supplyRaw ? Number(supplyRaw) / Math.pow(10, decimals) : 0;

    if (totalSupply === 0) return { topHoldersPct: 0, devHolderPct: 0, bundleDetected: false, holderCount: holders.length };

    // Resolve owners for top 10 accounts
    const ownerMap = new Map();
    await Promise.allSettled(
      holders.slice(0, 10).map(async holder => {
        try {
          const info = await conn.getParsedAccountInfo(holder.address);
          const owner = info.value?.data?.parsed?.info?.owner;
          if (owner) ownerMap.set(holder.address.toBase58(), owner);
        } catch {}
      })
    );

    const top10Amount = holders.slice(0, 10).reduce((s, h) => s + (h.uiAmount ?? 0), 0);
    const topHoldersPct = (top10Amount / totalSupply) * 100;

    let devHolderPct = 0;
    for (const holder of holders) {
      const owner = ownerMap.get(holder.address.toBase58());
      if (owner === creatorAddress) {
        devHolderPct = ((holder.uiAmount ?? 0) / totalSupply) * 100;
        break;
      }
    }

    const bundleDetected = detectBundles(holders.slice(0, 20), totalSupply);

    return {
      topHoldersPct,
      devHolderPct,
      bundleDetected,
      holderCount: holders.length,
      top10Holders: holders.slice(0, 10).map(h => ({
        address: h.address.toBase58(),
        amount: h.uiAmount,
        pct: ((h.uiAmount ?? 0) / totalSupply * 100).toFixed(2),
      })),
    };
  } catch (err) {
    logger.warn({ mint: mintAddress?.slice(0,8), err: err.message }, 'Holder analysis failed');
    return { topHoldersPct: 0, devHolderPct: 0, bundleDetected: false, holderCount: 0 };
  }
}

function detectBundles(holders, totalSupply) {
  if (holders.length < 3) return false;
  const amounts = holders.map(h => h.uiAmount ?? 0).filter(a => a > 0);
  for (let i = 0; i < amounts.length - 2; i++) {
    const base = amounts[i];
    if (base === 0) continue;
    let matchCount = 1;
    for (let j = i + 1; j < amounts.length; j++) {
      if (Math.abs(amounts[j] - base) / base < 0.005) matchCount++;
    }
    if (matchCount >= 3) {
      const pct = (base * matchCount / totalSupply) * 100;
      if (pct > 5) return true;
    }
  }
  return false;
}

export default { analyzeHolders };

/**
 * ReapX v4.0 — by ReapFX
 * @author  ReapFX <https://github.com/ReapFX>
 * @copyright 2025 ReapFX. All rights reserved.
 * This code is proprietary. Do not copy, distribute, or reuse without written permission from ReapFX.
 */
/**
 * ReapX — Live Dashboard Server
 *
 * Serves:
 *   GET  /api/stats        — overall PnL, win rate, trade count
 *   GET  /api/positions    — open positions with current P&L
 *   GET  /api/trades       — recent closed trades
 *   GET  /api/rpc          — RPC pool latency status
 *   GET  /api/jito         — Jito bundle land rate + current tip
 *   GET  /api/kol          — monitored KOL wallets
 *   WS   /ws               — real-time event stream (newToken, buy, sell, filter)
 *   GET  /                 — HTML dashboard UI
 */

import express from 'express';
import { WebSocketServer } from 'ws';
import http from 'http';
import { config } from '../config.js';
import { logger } from '../logger.js';
import { getTradeStats, getOpenTradesFromDb } from '../db.js';
import { getRpcPool } from '../rpc.js';
import { getJitoStats } from '../jito.js';
import { getOpenPositions } from '../position.js';

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

// ── WebSocket broadcast ───────────────────────────────────────────
const clients = new Set();

wss.on('connection', ws => {
  clients.add(ws);
  ws.on('close', () => clients.delete(ws));
});

export function broadcast(event, data) {
  const msg = JSON.stringify({ event, data, ts: Date.now() });
  for (const client of clients) {
    if (client.readyState === 1) client.send(msg);
  }
}

// ── REST API ──────────────────────────────────────────────────────
app.use(express.json());

app.get('/api/stats', (req, res) => {
  try { res.json(getTradeStats()); }
  catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/positions', (req, res) => {
  const positions = getOpenPositions().map(p => ({
    mint: p.mint,
    symbol: p.symbol,
    name: p.name,
    amountSol: p.amountSol,
    openedAt: p.openedAt,
    triggerType: p.triggerType,
    entryPrice: p.entryPrice,
    peakMultiplier: p.peakMultiplier,
    tpLevels: p.tpLevels,
  }));
  res.json(positions);
});

app.get('/api/rpc', (req, res) => {
  try { res.json(getRpcPool().getStatus()); }
  catch { res.json([]); }
});

app.get('/api/jito', (req, res) => {
  res.json(getJitoStats());
});

// ── HTML Dashboard ────────────────────────────────────────────────
app.get('/', (req, res) => {
  res.send(getDashboardHTML());
});

function getDashboardHTML() {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ReapX Dashboard</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#0a0a0a;color:#e0e0e0;font-size:14px}
.topbar{display:flex;align-items:center;gap:12px;padding:14px 20px;border-bottom:1px solid #1e1e1e;background:#111}
.logo{font-size:18px;font-weight:700;letter-spacing:.05em;color:#fff}
.logo span{color:#9b5cfa}
.dot{width:8px;height:8px;border-radius:50%;background:#22c55e;animation:pulse 2s infinite}
.dot.off{background:#ef4444;animation:none}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;padding:20px;max-width:1400px;margin:0 auto}
.card{background:#111;border:1px solid #1e1e1e;border-radius:12px;padding:16px}
.card h3{font-size:11px;font-weight:500;color:#666;text-transform:uppercase;letter-spacing:.08em;margin-bottom:8px}
.card .val{font-size:28px;font-weight:700;color:#fff}
.card .val.green{color:#22c55e}.card .val.red{color:#ef4444}.card .val.purple{color:#9b5cfa}
.section{max-width:1400px;margin:0 auto;padding:0 20px 20px}
.section h2{font-size:13px;font-weight:600;color:#888;text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px}
table{width:100%;border-collapse:collapse}
th{font-size:11px;color:#555;font-weight:500;text-transform:uppercase;padding:8px 12px;text-align:left;border-bottom:1px solid #1e1e1e}
td{padding:10px 12px;border-bottom:1px solid #141414;font-size:13px}
tr:hover td{background:#141414}
.badge{display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:500}
.badge.kol{background:#1a0a3d;color:#9b5cfa}
.badge.name{background:#0a1f3d;color:#60a5fa}
.badge.ticker{background:#0a2a1f;color:#34d399}
.badge.normal{background:#1a1a1a;color:#888}
.badge.dev{background:#2a1a0a;color:#fb923c}
.feed{height:300px;overflow-y:auto;font-family:monospace;font-size:12px;background:#0d0d0d;border:1px solid #1e1e1e;border-radius:8px;padding:12px}
.feed-line{padding:2px 0;border-bottom:1px solid #111;display:flex;gap:12px}
.feed-line .time{color:#444;min-width:60px}
.feed-line .type{min-width:80px}
.feed-line .type.buy{color:#22c55e}.feed-line .type.sell{color:#ef4444}
.feed-line .type.filter{color:#888}.feed-line .type.detect{color:#9b5cfa}
.rpc-list{display:flex;flex-direction:column;gap:6px}
.rpc-node{display:flex;align-items:center;gap:12px;padding:8px 12px;background:#111;border:1px solid #1e1e1e;border-radius:8px}
.rpc-url{flex:1;font-family:monospace;font-size:12px;color:#888}
.rpc-lat{font-size:13px;font-weight:600}
.rpc-lat.fast{color:#22c55e}.rpc-lat.med{color:#fbbf24}.rpc-lat.slow{color:#ef4444}
</style>
</head>
<body>
<div class="topbar">
  <span class="logo">Reap<span>X</span></span>
  <div class="dot" id="ws-dot"></div>
  <span id="ws-status" style="font-size:12px;color:#555">Connecting...</span>
  <span style="margin-left:auto;font-size:12px;color:#555" id="uptime"></span>
</div>

<div class="grid" id="stats-grid">
  <div class="card"><h3>Total P&L</h3><div class="val" id="s-pnl">—</div></div>
  <div class="card"><h3>Win rate</h3><div class="val purple" id="s-wr">—</div></div>
  <div class="card"><h3>Total trades</h3><div class="val" id="s-total">—</div></div>
  <div class="card"><h3>Open positions</h3><div class="val" id="s-open">—</div></div>
  <div class="card"><h3>Avg P&L</h3><div class="val" id="s-avg">—</div></div>
  <div class="card"><h3>Jito land rate</h3><div class="val purple" id="s-jito">—</div></div>
</div>

<div class="section">
  <h2>Open positions</h2>
  <table>
    <thead><tr><th>Token</th><th>Type</th><th>Entry</th><th>Peak</th><th>Invested</th><th>Opened</th></tr></thead>
    <tbody id="positions-body"><tr><td colspan="6" style="color:#555;text-align:center">No open positions</td></tr></tbody>
  </table>
</div>

<div class="section" style="margin-top:8px">
  <h2>Live feed</h2>
  <div class="feed" id="feed"></div>
</div>

<div class="section" style="margin-top:16px;display:grid;grid-template-columns:1fr 1fr;gap:16px">
  <div>
    <h2>Recent trades</h2>
    <table>
      <thead><tr><th>Token</th><th>Trigger</th><th>P&L</th><th>Exit</th></tr></thead>
      <tbody id="trades-body"></tbody>
    </table>
  </div>
  <div>
    <h2>RPC pool</h2>
    <div class="rpc-list" id="rpc-list"></div>
  </div>
</div>

<script>
const startTs = Date.now();
setInterval(() => {
  const s = Math.floor((Date.now()-startTs)/1000);
  document.getElementById('uptime').textContent = \`uptime \${Math.floor(s/3600)}h \${Math.floor((s%3600)/60)}m\`;
},1000);

// WebSocket
const ws = new WebSocket(\`ws://\${location.host}/ws\`);
ws.onopen = () => {
  document.getElementById('ws-dot').classList.remove('off');
  document.getElementById('ws-status').textContent = 'Live';
};
ws.onclose = () => {
  document.getElementById('ws-dot').classList.add('off');
  document.getElementById('ws-status').textContent = 'Disconnected — refresh to reconnect';
};
ws.onmessage = ({ data }) => {
  const { event, data: d, ts } = JSON.parse(data);
  addFeedLine(event, d, ts);
  if (event === 'buy' || event === 'sell' || event === 'stats') loadStats();
  if (event === 'buy' || event === 'sell') loadPositions();
};

function addFeedLine(type, d, ts) {
  const feed = document.getElementById('feed');
  const line = document.createElement('div');
  line.className = 'feed-line';
  const time = new Date(ts).toLocaleTimeString('en',{hour12:false,hour:'2-digit',minute:'2-digit',second:'2-digit'});
  const label = type === 'buy' ? 'BUY' : type === 'sell' ? 'SELL' : type === 'detect' ? 'DETECT' : 'FILTER';
  line.innerHTML = \`<span class="time">\${time}</span><span class="type \${type}">\${label}</span><span>\${d?.symbol ?? ''} \${d?.reason ?? d?.mint?.slice(0,12) ?? ''}</span>\`;
  feed.prepend(line);
  if (feed.children.length > 200) feed.lastChild.remove();
}

async function loadStats() {
  const [stats, jito, pos] = await Promise.all([
    fetch('/api/stats').then(r=>r.json()).catch(()=>({})),
    fetch('/api/jito').then(r=>r.json()).catch(()=>({})),
    fetch('/api/positions').then(r=>r.json()).catch(()=>[]),
  ]);
  const pnl = stats.totalPnlSol ?? 0;
  document.getElementById('s-pnl').textContent = (pnl >= 0 ? '+' : '') + pnl.toFixed(4) + ' SOL';
  document.getElementById('s-pnl').className = 'val ' + (pnl >= 0 ? 'green' : 'red');
  document.getElementById('s-wr').textContent = (stats.winRate ?? 0) + '%';
  document.getElementById('s-total').textContent = stats.totalTrades ?? 0;
  document.getElementById('s-open').textContent = pos.length;
  const avg = stats.avgPnlPct ?? 0;
  document.getElementById('s-avg').textContent = (avg >= 0 ? '+' : '') + avg.toFixed(1) + '%';
  document.getElementById('s-avg').className = 'val ' + (avg >= 0 ? 'green' : 'red');
  document.getElementById('s-jito').textContent = (jito.landRate ?? 0) + '%';
}

async function loadPositions() {
  const pos = await fetch('/api/positions').then(r=>r.json()).catch(()=>[]);
  const tbody = document.getElementById('positions-body');
  if (!pos.length) {
    tbody.innerHTML = '<tr><td colspan="6" style="color:#555;text-align:center">No open positions</td></tr>';
    return;
  }
  tbody.innerHTML = pos.map(p => {
    const age = Math.floor((Date.now() - p.openedAt) / 1000);
    const ageStr = age < 60 ? age + 's' : Math.floor(age/60) + 'm';
    const badgeClass = p.triggerType.includes('kol') ? 'kol' : p.triggerType.includes('name') ? 'name' : p.triggerType.includes('ticker') ? 'ticker' : p.triggerType === 'dev_wallet' ? 'dev' : 'normal';
    return \`<tr>
      <td><strong>\${p.symbol}</strong> <span style="color:#555">\${p.mint.slice(0,8)}...</span></td>
      <td><span class="badge \${badgeClass}">\${p.triggerType}</span></td>
      <td style="font-family:monospace">\${p.entryPrice?.toExponential(3) ?? '—'}</td>
      <td style="color:\${p.peakMultiplier > 1 ? '#22c55e' : '#888'}">\${(p.peakMultiplier ?? 1).toFixed(2)}x</td>
      <td>\${p.amountSol?.toFixed(3)} SOL</td>
      <td style="color:#555">\${ageStr} ago</td>
    </tr>\`;
  }).join('');
}

async function loadTrades() {
  const stats = await fetch('/api/stats').then(r=>r.json()).catch(()=>({}));
  const trades = stats.recentTrades ?? [];
  document.getElementById('trades-body').innerHTML = trades.map(t => {
    const pnl = t.pnl_sol ?? 0;
    return \`<tr>
      <td><strong>\${t.symbol || '???'}</strong></td>
      <td><span class="badge \${t.trigger_type.includes('kol')?'kol':t.trigger_type.includes('name')?'name':'normal'}">\${t.trigger_type}</span></td>
      <td style="color:\${pnl>=0?'#22c55e':'#ef4444'};font-family:monospace">\${pnl>=0?'+':''}\${pnl.toFixed(4)}</td>
      <td style="color:#555">\${t.exit_reason ?? '—'}</td>
    </tr>\`;
  }).join('') || '<tr><td colspan="4" style="color:#555">No trades yet</td></tr>';
}

async function loadRpc() {
  const nodes = await fetch('/api/rpc').then(r=>r.json()).catch(()=>[]);
  document.getElementById('rpc-list').innerHTML = nodes.map(n => {
    const latClass = n.latencyMs < 100 ? 'fast' : n.latencyMs < 300 ? 'med' : 'slow';
    return \`<div class="rpc-node">
      <div class="dot \${n.healthy?'':'off'}" style="flex-shrink:0"></div>
      <span class="rpc-url">\${n.url.slice(0,50)}</span>
      <span class="rpc-lat \${latClass}">\${n.latencyMs}ms</span>
    </div>\`;
  }).join('');
}

// Initial load
loadStats(); loadPositions(); loadTrades(); loadRpc();
setInterval(loadStats, 15000);
setInterval(loadPositions, 15000);
setInterval(loadRpc, 30000);
setInterval(loadTrades, 30000);
</script>
</body>
</html>`;
}

export function startDashboard() {
  if (!config.dashboardEnabled) return;
  server.listen(config.dashboardPort, () => {
    logger.info({ port: config.dashboardPort }, `📊 Dashboard: http://localhost:${config.dashboardPort}`);
  });
}

export default { startDashboard, broadcast };

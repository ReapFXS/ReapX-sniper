/**
 * ReapX v4.0 — by ReapFX
 * @author  ReapFX <https://github.com/ReapFX>
 * @copyright 2025 ReapFX. All rights reserved.
 * This code is proprietary. Do not copy, distribute, or reuse without written permission from ReapFX.
 */

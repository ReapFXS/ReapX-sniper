/**
 * ReapX v4.0 — by ReapFX
 * @author  ReapFX <https://github.com/ReapFX>
 * @copyright 2025 ReapFX. All rights reserved.
 * This code is proprietary. Do not copy, distribute, or reuse without written permission from ReapFX.
 */
import axios from 'axios';
import { logger } from './logger.js';

const RUGCHECK_BASE = 'https://api.rugcheck.xyz/v1';
const cache = new Map();

export async function getRugCheckReport(mintAddress) {
  if (cache.has(mintAddress)) return cache.get(mintAddress);
  try {
    const { data } = await axios.get(`${RUGCHECK_BASE}/tokens/${mintAddress}/report/summary`, { timeout: 8000 });
    cache.set(mintAddress, data);
    // Evict after 5 min
    setTimeout(() => cache.delete(mintAddress), 5 * 60 * 1000);
    return data;
  } catch (err) {
    logger.warn({ mint: mintAddress?.slice(0,8), err: err.message }, 'RugCheck API failed');
    return null;
  }
}

export default { getRugCheckReport };

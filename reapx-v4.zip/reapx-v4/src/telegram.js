/**
 * ReapX v4.0 — by ReapFX
 * @author  ReapFX <https://github.com/ReapFX>
 * @copyright 2025 ReapFX. All rights reserved.
 * This code is proprietary. Do not copy, distribute, or reuse without written permission from ReapFX.
 */
import TelegramBot from 'node-telegram-bot-api';
import { config } from './config.js';
import { logger } from './logger.js';

let bot = null;

if (config.telegramEnabled && config.telegramToken) {
  try {
    bot = new TelegramBot(config.telegramToken, { polling: false });
    logger.info('📱 Telegram alerts enabled');
  } catch (err) {
    logger.warn({ err: err.message }, 'Telegram init failed');
  }
}

export async function notify(message) {
  if (!bot || !config.telegramChatId) return;
  try {
    await bot.sendMessage(config.telegramChatId, message, {
      parse_mode: 'Markdown',
      disable_web_page_preview: true,
    });
  } catch (err) {
    logger.warn({ err: err.message }, 'Telegram send failed');
  }
}

export default { notify };

/**
 * ReapX v4.0 — by ReapFX
 * @author  ReapFX <https://github.com/ReapFX>
 * @copyright 2025 ReapFX. All rights reserved.
 * This code is proprietary. Do not copy, distribute, or reuse without written permission from ReapFX.
 */
import 'dotenv/config';

function req(key) {
  const v = process.env[key];
  if (!v || v.startsWith('your_')) throw new Error(`Missing env var: ${key}`);
  return v;
}
function opt(key, fallback) { return process.env[key] ?? fallback; }

const isPaper = process.argv.includes('--paper') || opt('PAPER_MODE', 'false') === 'true';

// ── Targeted snipe lists ──────────────────────────────────────────
const nameTargets   = opt('NAME_SNIPE_TARGETS', '').split(',').map(s => s.trim().toUpperCase()).filter(Boolean);
const tickerTargets = opt('TICKER_SNIPE_TARGETS', '').split(',').map(s => s.trim().toUpperCase().replace('$','')).filter(Boolean);
const devWalletTargets = opt('DEV_WALLET_TARGETS', '').split(',').map(s => s.trim()).filter(Boolean);

// ── KOL wallets to copy-trade ─────────────────────────────────────
// Format: address:label,address:label  e.g. "3xABC...def:whale1,7yDEF...ghi:alpha2"
const kolWallets = opt('KOL_WALLETS', '').split(',')
  .map(s => { const [addr, label] = s.trim().split(':'); return addr ? { addr: addr.trim(), label: label?.trim() ?? addr.slice(0,8) } : null; })
  .filter(Boolean);

export const config = {
  // ── Mode ──────────────────────────────────────────────────────────
  paperMode: isPaper,

  // ── Wallet & RPCs ─────────────────────────────────────────────────
  privateKey: isPaper ? null : req('PRIVATE_KEY'),

  // Multi-RPC pool — ReapX will auto-route to fastest and failover
  rpcUrls: opt('RPC_URLS', opt('RPC_URL', 'https://api.mainnet-beta.solana.com'))
    .split(',').map(s => s.trim()).filter(Boolean),

  // Geyser gRPC (Yellowstone) — vastly faster than WebSocket
  // Get from Helius: https://dashboard.helius.dev → gRPC
  geyserEndpoint: opt('GEYSER_ENDPOINT', ''),
  geyserToken:    opt('GEYSER_TOKEN', ''),

  // Jito
  jitoUrl: opt('JITO_URL', 'https://mainnet.block-engine.jito.wtf'),

  // ── Trading ───────────────────────────────────────────────────────
  buyAmountSol:        parseFloat(opt('BUY_AMOUNT_SOL', '0.1')),
  targetedBuyAmountSol: parseFloat(opt('TARGETED_BUY_AMOUNT_SOL', opt('BUY_AMOUNT_SOL', '0.1'))),
  kolBuyAmountSol:     parseFloat(opt('KOL_BUY_AMOUNT_SOL', opt('BUY_AMOUNT_SOL', '0.1'))),
  slippageBps:         parseInt(opt('SLIPPAGE_BPS', '500')),
  maxConcurrentSnipes: parseInt(opt('MAX_CONCURRENT_SNIPES', '3')),

  // Dynamic Jito tip — ReapX scales between min and max based on competition
  jitoTipMinSol: parseFloat(opt('JITO_TIP_MIN_SOL', '0.002')),
  jitoTipMaxSol: parseFloat(opt('JITO_TIP_MAX_SOL', '0.05')),
  jitoTipSol:    parseFloat(opt('JITO_TIP_SOL', '0.005')), // static fallback

  // ── Filters ───────────────────────────────────────────────────────
  minRugcheckScore:   parseInt(opt('MIN_RUGCHECK_SCORE', '75')),
  maxTop10HolderPct:  parseFloat(opt('MAX_TOP10_HOLDER_PCT', '40')),
  maxDevHolderPct:    parseFloat(opt('MAX_DEV_HOLDER_PCT', '10')),
  minLiquidityUsd:    parseFloat(opt('MIN_LIQUIDITY_USD', '3000')),
  skipBundled:        opt('SKIP_BUNDLED', 'true') === 'true',

  // Minimum conviction score (0–100) to fire a normal snipe
  minConvictionScore: parseInt(opt('MIN_CONVICTION_SCORE', '60')),

  // Targeted snipes bypass filters
  targetedSkipFilters: opt('TARGETED_SKIP_FILTERS', 'true') === 'true',

  // ── Exit ──────────────────────────────────────────────────────────
  takeProfitMultipliers: opt('TAKE_PROFIT_MULTIPLIERS', '2,3,5').split(',').map(Number),
  takeProfitPercents:    opt('TAKE_PROFIT_PERCENTS', '30,30,20').split(',').map(Number),
  stopLossPct:           parseFloat(opt('STOP_LOSS_PCT', '40')),
  // Trailing stop — if set, overrides fixed SL once position is >1x
  trailingStopPct:       parseFloat(opt('TRAILING_STOP_PCT', '0')), // 0 = disabled

  // ── Telegram ──────────────────────────────────────────────────────
  telegramEnabled: opt('TELEGRAM_ENABLED', 'false') === 'true',
  telegramToken:   opt('TELEGRAM_BOT_TOKEN', ''),
  telegramChatId:  opt('TELEGRAM_CHAT_ID', ''),

  // ── Targeted sniping ──────────────────────────────────────────────
  nameSnipeTargets:    nameTargets,
  tickerSnipeTargets:  tickerTargets,
  devWalletTargets:    devWalletTargets,

  // ── KOL copy-trade ────────────────────────────────────────────────
  kolWallets,
  kolCopyEnabled:     opt('KOL_COPY_ENABLED', 'false') === 'true',
  kolMaxDelayMs:      parseInt(opt('KOL_MAX_DELAY_MS', '5000')), // ignore if KOL bought >Xms ago

  // ── Dev wallet reputation ─────────────────────────────────────────
  // Requires sqlite DB — tracks all devs we've seen
  devReputationEnabled: opt('DEV_REPUTATION_ENABLED', 'true') === 'true',

  // ── Social signals ────────────────────────────────────────────────
  // Supply your own Twitter/X bearer token for social scoring
  twitterBearerToken: opt('TWITTER_BEARER_TOKEN', ''),
  socialSignalEnabled: opt('SOCIAL_SIGNAL_ENABLED', 'false') === 'true',

  // ── Dashboard ─────────────────────────────────────────────────────
  dashboardEnabled: opt('DASHBOARD_ENABLED', 'true') === 'true',
  dashboardPort:    parseInt(opt('DASHBOARD_PORT', '3000')),

  // ── Database ──────────────────────────────────────────────────────
  dbPath: opt('DB_PATH', './reapx.db'),

  get hasTargetedMode() {
    return this.nameSnipeTargets.length > 0 || this.tickerSnipeTargets.length > 0 || this.devWalletTargets.length > 0;
  },
};

if (config.takeProfitMultipliers.length !== config.takeProfitPercents.length) {
  throw new Error('TAKE_PROFIT_MULTIPLIERS and TAKE_PROFIT_PERCENTS must have equal length');
}

export default config;

/**
 * ReapX v4.0 — Main Entry Point
 * @author  ReapFX <https://github.com/ReapFX>
 * @copyright 2025 ReapFX. All rights reserved.
 * This code is proprietary. Do not copy, distribute, or reuse without written permission from ReapFX.
 *
 * Pipeline:
 *   Geyser/WS → targeted check → KOL check → conviction score → buy → position manager
 */

import { config } from './config.js';
import { logger } from './logger.js';
import { getRpcPool } from './rpc.js';
import { TokenListener } from './listener.js';
import { KolMonitor } from './kol.js';
import { analyzeHolders } from './holders.js';
import { scoreToken, sizeBuy } from './conviction.js';
import { buy, getWallet } from './trader.js';
import { openPosition, checkPositions, getOpenPositions, hasPosition, getPositionCount } from './position.js';
import { notify } from './telegram.js';
import { checkTargetMatch, logTargetSummary } from './targeted.js';
import { upsertDevWallet, insertTrade, markKolCopied, getDb } from './db.js';
import { startDashboard, broadcast } from './dashboard/server.js';

// ── State ─────────────────────────────────────────────────────────
const processing = new Set();
let totalSnipes = 0;
let totalFiltered = 0;
let totalTargeted = 0;
let totalKol = 0;
const startTime = Date.now();

// ── Banner ────────────────────────────────────────────────────────
function printBanner() {
  console.log('\n');
  console.log('  ██████╗ ███████╗ █████╗ ██████╗ ██╗  ██╗');
  console.log('  ██╔══██╗██╔════╝██╔══██╗██╔══██╗╚██╗██╔╝');
  console.log('  ██████╔╝█████╗  ███████║██████╔╝ ╚███╔╝ ');
  console.log('  ██╔══██╗██╔══╝  ██╔══██║██╔═══╝  ██╔██╗ ');
  console.log('  ██║  ██║███████╗██║  ██║██║     ██╔╝ ██╗');
  console.log('  ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝');
  console.log('');
  console.log('        Elite Solana Sniper  ·  v4.0');
  console.log('        by ReapFX — github.com/ReapFX');
  console.log('        © 2025 ReapFX. All rights reserved.');
  console.log('');
  console.log(`  Mode        : ${config.paperMode ? '📝 PAPER (no real trades)' : '🔴 LIVE'}`);
  console.log(`  RPC nodes   : ${config.rpcUrls.length} (${config.geyserEndpoint ? '⚡ Geyser active' : '🔌 WebSocket fallback'})`);
  console.log(`  Buy size    : ${config.buyAmountSol} SOL  (targeted: ${config.targetedBuyAmountSol} SOL)`);
  console.log(`  Jito tip    : ${config.jitoTipMinSol}–${config.jitoTipMaxSol} SOL (dynamic)`);
  console.log(`  Stop loss   : -${config.stopLossPct}%${config.trailingStopPct > 0 ? ` + trailing -${config.trailingStopPct}%` : ''}`);
  console.log(`  TP ladder   : ${config.takeProfitMultipliers.map((m, i) => `${m}x→${config.takeProfitPercents[i]}%`).join(', ')}`);
  console.log(`  Conviction  : min ${config.minConvictionScore}/100`);
  console.log(`  KOL wallets : ${config.kolCopyEnabled ? config.kolWallets.length + ' tracked' : 'disabled'}`);
  console.log(`  Social      : ${config.socialSignalEnabled ? '✅ Twitter' : '❌ disabled'}`);
  console.log(`  Dashboard   : ${config.dashboardEnabled ? `http://localhost:${config.dashboardPort}` : 'disabled'}`);
  console.log(`  Telegram    : ${config.telegramEnabled ? '✅' : '❌'}`);
  console.log('\n');
}

// ── Targeted snipe handler ────────────────────────────────────────
async function handleTargetedSnipe({ mint, creator, name, symbol, signature, timestamp, matchReason, matchType }) {
  if (processing.has(mint) || hasPosition(mint)) return;
  processing.add(mint);

  logger.info({ mint: mint.slice(0, 8), name, symbol, reason: matchReason }, '🎯 TARGETED SNIPE');
  broadcast('detect', { mint, symbol, name, reason: matchReason, type: matchType });

  await notify(
    `🎯 *Targeted Snipe*\n` +
    `Token: \`${symbol}\` (${name})\n` +
    `Reason: ${matchReason}\n` +
    `${config.targetedSkipFilters ? '⚡ Filters bypassed — instant entry' : '🔍 Filters applied'}`
  );

  try {
    if (!config.targetedSkipFilters) {
      const holderData = await analyzeHolders(mint, creator);
      const result = await scoreToken({ mint, creator, symbol, name, holderData, launchTimestamp: timestamp });
      if (!result.pass) {
        logger.warn({ mint: mint.slice(0, 8), reason: result.reason }, '🚫 Targeted token failed filters');
        await notify(`⚠️ Targeted \`${symbol}\` failed filter: ${result.reason}`);
        processing.delete(mint);
        return;
      }
    }

    const buyResult = await buy(mint, config.targetedBuyAmountSol, true);

    if (!buyResult.success) {
      logger.error({ mint: mint.slice(0, 8), err: buyResult.error }, '❌ Targeted buy failed');
      await notify(`❌ Targeted buy failed: \`${symbol}\`\n${buyResult.error}`);
      processing.delete(mint);
      return;
    }

    totalSnipes++;
    totalTargeted++;

    const tradeId = insertTrade({
      mint, symbol, name, creator,
      triggerType: `targeted_${matchType}`,
      triggerDetail: matchReason,
      conviction: 100,
      buySol: config.targetedBuyAmountSol,
      buyPrice: buyResult.entryPrice,
      tokenAmount: buyResult.amountOut,
      buySig: buyResult.signature,
      paper: buyResult.paper,
    });

    openPosition(mint, buyResult, { tradeId, symbol, name, creator, triggerType: `targeted_${matchType}` });
    broadcast('buy', { mint, symbol, reason: matchReason, sol: config.targetedBuyAmountSol, sig: buyResult.signature?.slice(0, 16) });

    await notify(
      `✅ *Targeted Buy* \`${symbol}\`\n` +
      `Reason: ${matchReason}\n` +
      `Amount: ${config.targetedBuyAmountSol} SOL\n` +
      `Sig: \`${buyResult.signature?.slice(0, 16)}...\`\n` +
      `TP: ${config.takeProfitMultipliers.join('x / ')}x | SL: -${config.stopLossPct}%`
    );
  } catch (err) {
    logger.error({ err: err.message, mint }, 'Error in handleTargetedSnipe');
  } finally {
    processing.delete(mint);
  }
}

// ── KOL copy-trade handler ────────────────────────────────────────
async function handleKolBuy({ kolAddr, kolLabel, mint, timestamp }) {
  if (processing.has(mint) || hasPosition(mint)) return;
  if (getPositionCount() >= config.maxConcurrentSnipes) return;

  const delayMs = Date.now() - timestamp;
  if (delayMs > config.kolMaxDelayMs) {
    logger.debug({ mint: mint.slice(0, 8), delayMs }, 'KOL copy skipped — too late');
    return;
  }

  processing.add(mint);
  logger.info({ kol: kolLabel, mint: mint.slice(0, 8), delayMs }, `👁️  Copying KOL: ${kolLabel}`);
  broadcast('detect', { mint, symbol: '?', reason: `KOL copy: ${kolLabel}`, type: 'kol' });

  try {
    const buyResult = await buy(mint, config.kolBuyAmountSol, true);

    if (!buyResult.success) {
      logger.error({ mint: mint.slice(0, 8), err: buyResult.error }, '❌ KOL copy buy failed');
      processing.delete(mint);
      return;
    }

    totalSnipes++;
    totalKol++;
    markKolCopied(mint, kolAddr);

    const tradeId = insertTrade({
      mint, symbol: '?', name: '', creator: '',
      triggerType: 'kol_copy',
      triggerDetail: kolLabel,
      conviction: 80,
      buySol: config.kolBuyAmountSol,
      buyPrice: buyResult.entryPrice,
      tokenAmount: buyResult.amountOut,
      buySig: buyResult.signature,
      paper: buyResult.paper,
    });

    openPosition(mint, buyResult, { tradeId, symbol: '?', name: '', triggerType: 'kol_copy' });
    broadcast('buy', { mint, symbol: '?', reason: `KOL: ${kolLabel}`, sol: config.kolBuyAmountSol });

    await notify(
      `👁️ *KOL Copy* — ${kolLabel}\n` +
      `Mint: \`${mint}\`\n` +
      `Amount: ${config.kolBuyAmountSol} SOL\n` +
      `Delay: ${delayMs}ms`
    );
  } catch (err) {
    logger.error({ err: err.message }, 'Error in handleKolBuy');
  } finally {
    processing.delete(mint);
  }
}

// ── Normal token handler ──────────────────────────────────────────
async function handleNewToken({ mint, creator, name, symbol, signature, timestamp }) {
  if (processing.has(mint) || hasPosition(mint)) return;
  if (getPositionCount() >= config.maxConcurrentSnipes) {
    logger.debug({ mint: mint.slice(0, 8) }, 'Max concurrent snipes reached');
    return;
  }

  // ── 1. Targeted check (fast path) ────────────────────────────────
  const targetMatch = checkTargetMatch({ name, symbol, creator });
  if (targetMatch.matched) {
    return handleTargetedSnipe({ mint, creator, name, symbol, signature, timestamp, matchReason: targetMatch.reason, matchType: targetMatch.type });
  }

  processing.add(mint);

  const age = ((Date.now() - timestamp) / 1000).toFixed(1);
  logger.info({ mint: mint.slice(0, 8), name, symbol, age: `${age}s` }, '🆕 New token');
  broadcast('detect', { mint, symbol, name, age });

  if (creator) upsertDevWallet(creator);

  try {
    // ── 2. Holder analysis ────────────────────────────────────────
    const holderData = await analyzeHolders(mint, creator);

    // ── 3. Conviction score ───────────────────────────────────────
    const scored = await scoreToken({ mint, creator, symbol, name, holderData, launchTimestamp: timestamp });

    if (!scored.pass) {
      logger.info({ mint: mint.slice(0, 8), score: scored.score, reason: scored.reason }, '🚫 Filtered');
      totalFiltered++;
      broadcast('filter', { mint, symbol, score: scored.score, reason: scored.reason });
      processing.delete(mint);
      return;
    }

    // ── 4. Size buy by conviction ─────────────────────────────────
    const buySol = sizeBuy(scored.score, config.buyAmountSol);

    logger.info({
      mint: mint.slice(0, 8), symbol,
      score: scored.score,
      buySol,
      devPct: holderData.devHolderPct?.toFixed(1),
      top10: holderData.topHoldersPct?.toFixed(1),
    }, '✅ Conviction passed — sniping');

    await notify(
      `🎯 *Sniping* \`${symbol}\` (${name})\n` +
      `Score: ${scored.score}/100 | Buy: ${buySol.toFixed(3)} SOL\n` +
      `Dev: ${holderData.devHolderPct?.toFixed(1)}% | Top10: ${holderData.topHoldersPct?.toFixed(1)}%\n` +
      `Bundle: ${holderData.bundleDetected ? '⚠️ YES' : '✅ No'}`
    );

    // ── 5. Buy ────────────────────────────────────────────────────
    const buyResult = await buy(mint, buySol, false);

    if (!buyResult.success) {
      logger.error({ mint: mint.slice(0, 8), err: buyResult.error }, '❌ Buy failed');
      await notify(`❌ Buy failed: \`${symbol}\`\n${buyResult.error}`);
      processing.delete(mint);
      return;
    }

    totalSnipes++;

    // ── 6. Record & open position ─────────────────────────────────
    const tradeId = insertTrade({
      mint, symbol, name, creator,
      triggerType: 'normal',
      conviction: scored.score,
      buySol,
      buyPrice: buyResult.entryPrice,
      tokenAmount: buyResult.amountOut,
      buySig: buyResult.signature,
      paper: buyResult.paper,
    });

    openPosition(mint, buyResult, { tradeId, symbol, name, creator, triggerType: 'normal' });
    broadcast('buy', { mint, symbol, score: scored.score, sol: buySol, sig: buyResult.signature?.slice(0, 16) });

    await notify(
      `✅ *Bought* \`${symbol}\`\n` +
      `${buySol.toFixed(3)} SOL | Score: ${scored.score}/100\n` +
      `Sig: \`${buyResult.signature?.slice(0, 16)}...\`\n` +
      `TP: ${config.takeProfitMultipliers.join('x / ')}x | SL: -${config.stopLossPct}%`
    );

  } catch (err) {
    logger.error({ err: err.message, mint }, 'Error in handleNewToken');
  } finally {
    processing.delete(mint);
  }
}

// ── Migration handler ─────────────────────────────────────────────
async function handleMigration({ mint, raydiumPool, signature }) {
  if (hasPosition(mint) || getPositionCount() >= config.maxConcurrentSnipes) return;
  logger.info({ mint: mint.slice(0, 8), raydiumPool }, '⚡ Raydium migration detected');
  await handleNewToken({ mint, creator: '', name: 'MIGRATED', symbol: '???', signature, timestamp: Date.now() });
}

// ── Main ──────────────────────────────────────────────────────────
async function main() {
  printBanner();
  logTargetSummary();

  getDb();
  const pool = getRpcPool();
  pool.start();
  startDashboard();

  if (!config.paperMode) {
    const wallet = getWallet();
    logger.info({ pubkey: wallet.publicKey.toBase58() }, '🔑 Wallet ready');
  }

  const listener = new TokenListener();
  listener.on('newToken', handleNewToken);
  listener.on('migration', handleMigration);
  listener.on('error', err => {
    logger.error({ err: err.message }, 'Listener error — reconnecting in 5s');
    setTimeout(async () => {
      if (listener._running) {
        try { await listener.stop(); } catch {}
        try { await listener.start(); } catch {}
      }
    }, 5000);
  });
  await listener.start();

  const kolMonitor = new KolMonitor();
  kolMonitor.on('kolBuy', handleKolBuy);
  kolMonitor.on('error', err => logger.warn({ err: err.message }, 'KOL monitor error'));
  await kolMonitor.start();

  const positionInterval = setInterval(async () => {
    if (getPositionCount() > 0) {
      await checkPositions();
      broadcast('positions', getOpenPositions().map(p => ({
        mint: p.mint, symbol: p.symbol,
        peakMultiplier: p.peakMultiplier,
        amountSol: p.amountSol,
      })));
    }
  }, 15_000);

  const statsInterval = setInterval(() => {
    const uptime = Math.floor((Date.now() - startTime) / 1000);
    const stats = { totalSnipes, totalFiltered, totalTargeted, totalKol, uptime };
    logger.info(stats, '📊 ReapX Stats');
    broadcast('stats', stats);
  }, 5 * 60 * 1000);

  async function shutdown(signal) {
    logger.info({ signal }, '🛑 Shutting down ReapX...');
    clearInterval(positionInterval);
    clearInterval(statsInterval);
    pool.stop();
    await listener.stop();
    await kolMonitor.stop();
    await notify('🛑 ReapX stopped');
    process.exit(0);
  }

  process.on('SIGINT',  () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('uncaughtException',  err => logger.error({ err: err.message }, 'Uncaught exception'));
  process.on('unhandledRejection', err => logger.error({ err: String(err) }, 'Unhandled rejection'));

  logger.info('🚀 ReapX is live — by ReapFX (github.com/ReapFX)');

  await notify(
    `🚀 *ReapX v4.0 started*${config.paperMode ? ' (PAPER)' : ''}\n` +
    `RPCs: ${config.rpcUrls.length} | Geyser: ${config.geyserEndpoint ? '✅' : '❌'}\n` +
    `KOL: ${config.kolCopyEnabled ? config.kolWallets.length + ' wallets' : 'off'} | Social: ${config.socialSignalEnabled ? '✅' : '❌'}\n` +
    (config.hasTargetedMode
      ? `🎯 Targets: ${[...config.nameSnipeTargets, ...config.tickerSnipeTargets.map(t => '$' + t)].join(', ')}\n`
      : '') +
    `_by ReapFX — github.com/ReapFX_`
  );
}

main().catch(err => {
  logger.error({ err: err.message }, 'Fatal startup error');
  process.exit(1);
});

> **Author:** ReapFX — https://github.com/ReapFX
> **Copyright:** © 2025 ReapFX. All rights reserved.
> This code is proprietary. Do not copy, distribute, or reuse without written permission.

# ██████╗ ███████╗ █████╗ ██████╗ ██╗  ██╗
# ██╔══██╗██╔════╝██╔══██╗██╔══██╗╚██╗██╔╝
# ██████╔╝█████╗  ███████║██████╔╝ ╚███╔╝
# ██╔══██╗██╔══╝  ██╔══██║██╔═══╝  ██╔██╗
# ██║  ██║███████╗██║  ██║██║     ██╔╝ ██╗
# ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝
#
#   Elite Solana Sniper  ·  ReapFX  ·  v4.0

**ReapX** is a production-grade Solana memecoin sniper built by ReapFX.

---

## What makes ReapX different

| Feature | Most bots | ReapX |
|---------|-----------|-------|
| Detection speed | WebSocket (~150ms) | **Geyser gRPC (~10ms)** |
| RPC reliability | Single endpoint | **Multi-RPC pool + failover** |
| Filter logic | Binary pass/fail | **0–100 conviction score** |
| Buy sizing | Fixed | **Scales with conviction** |
| Jito tip | Fixed | **Dynamic — adapts to competition** |
| Targets | None | **Name + ticker + dev wallet** |
| Copy-trade | None | **KOL wallet monitor** |
| Dev history | None | **SQLite reputation DB** |
| Social signals | None | **Twitter mention velocity** |
| Exit logic | Fixed TP/SL | **TP ladder + trailing stop** |
| Observability | Logs only | **Live web dashboard + WebSocket** |
| Backtesting | None | **Full replay engine** |

---

## Quick start

```bash
git clone <repo> && cd reapx
npm install
cp .env.example .env
# Fill in .env — at minimum: PRIVATE_KEY + RPC_URLS
npm run paper     # test without spending real SOL
npm start         # live trading
```

Dashboard opens at **http://localhost:3000**

---

## Architecture

```
Geyser gRPC ──┐
              ├── Token Listener
WebSocket ────┘        │
                       ▼
               Targeted Match? ──► Instant buy (skip filters)
                       │
                       ▼
               Holder Analysis
                       │
                       ▼
               Conviction Scorer ──── RugCheck
               (0–100 score)    ──── Dev reputation
                                ──── Social signals
                                ──── Launch timing
                       │
                 score >= min? ──No──► Skip
                       │
                       ▼
               Size Buy by Score
               (higher conviction = larger position)
                       │
                       ▼
               Jito Bundle (dynamic tip)
               ── fallback: RPC pool send
                       │
                       ▼
               Position Manager
               ── TP ladder
               ── Trailing stop
               ── Hard SL
               ── SQLite PnL record

KOL Monitor ──► kolBuy event ──► Instant copy
```

---

## Modules

| File | Purpose |
|------|---------|
| `src/index.js` | Main entry — wires all modules |
| `src/config.js` | All settings from env |
| `src/listener.js` | Geyser gRPC + WebSocket fallback |
| `src/rpc.js` | Multi-RPC pool, latency routing, failover |
| `src/conviction.js` | Multi-factor scorer (0–100) |
| `src/kol.js` | KOL wallet copy-trade monitor |
| `src/social.js` | Twitter mention velocity scoring |
| `src/targeted.js` | Name / ticker / dev wallet matching |
| `src/holders.js` | Holder concentration + bundle detection |
| `src/rugcheck.js` | RugCheck API with cache |
| `src/jito.js` | Jito bundle submit + dynamic tip |
| `src/trader.js` | Jupiter buy/sell via RPC pool |
| `src/position.js` | TP/SL/trailing stop + PnL tracking |
| `src/db.js` | SQLite — trades, dev reputation, KOL log |
| `src/telegram.js` | Alert notifications |
| `src/backtest.js` | Strategy replay engine |
| `src/dashboard/server.js` | Live web dashboard + WebSocket |

---

## Targeted sniping

Three modes, combinable:

```env
# Snipe the moment a token named exactly "PEPE" launches
NAME_SNIPE_TARGETS=PEPE,TRUMP

# Snipe by ticker symbol
TICKER_SNIPE_TARGETS=PEPE,WIF,BONK

# Auto-snipe anything launched by these dev wallets
DEV_WALLET_TARGETS=3xWalletAddr...,7yOtherAddr...
```

Targeted snipes use `TARGETED_BUY_AMOUNT_SOL` and bypass filters by default (`TARGETED_SKIP_FILTERS=true`).

---

## KOL copy-trade

```env
KOL_COPY_ENABLED=true
KOL_WALLETS=3xWhaleAddr...:whale1,7yAlphaAddr...:alpha2
KOL_BUY_AMOUNT_SOL=0.15
KOL_MAX_DELAY_MS=5000   # ignore if >5s since KOL bought
```

ReapX subscribes to each KOL's token accounts. When a new token account appears (= buy), it copies within `KOL_MAX_DELAY_MS`.

---

## Conviction scoring

Replaces binary filters with a weighted score (0–100):

| Factor | Max pts | Notes |
|--------|---------|-------|
| RugCheck score | 30 | Hard reject if below `MIN_RUGCHECK_SCORE` |
| Holder concentration | 20 | Lower top-10% = higher score |
| Dev wallet reputation | 20 | Built from historical launches in SQLite |
| Social mentions | 10 | Twitter velocity (requires `TWITTER_BEARER_TOKEN`) |
| Launch timing | 10 | Fresh launches score higher |

Buy size scales with score:
- **≥85** → full `BUY_AMOUNT_SOL`
- **≥70** → 75%
- **≥60** → 50%
- **<60** → skipped

---

## Backtest

```bash
node src/backtest.js --limit 2000 --days 7
```

Replays historical launches through your filter + exit config and reports:
- Win rate, avg P&L, estimated SOL P&L
- P&L distribution buckets
- Exit reason breakdown
- Filter rejection breakdown

---

## Dashboard

Live at `http://localhost:3000` (or `DASHBOARD_PORT`):

- Real-time P&L, win rate, trade count
- Open positions with peak multiplier
- Live event feed (WebSocket)
- RPC pool latency per node
- Jito bundle land rate + current tip
- Recent closed trades table

---

## Recommended setup (Helius)

1. Get a free Helius key at [helius.dev](https://dashboard.helius.dev)
2. Set `RPC_URLS=https://mainnet.helius-rpc.com/?api-key=YOUR_KEY`
3. Enable gRPC in Helius dashboard → copy endpoint + token
4. Set `GEYSER_ENDPOINT` and `GEYSER_TOKEN`

This gives you ~10ms detection vs ~150ms on public WebSocket.

---

## Warning

This software trades real SOL. Use a **dedicated bot wallet** funded with only what you're willing to lose. Always test with `npm run paper` first.

---

---

**ReapX v4.0** — built by [ReapFX](https://github.com/ReapFX)
© 2025 ReapFX. All rights reserved.
This code is proprietary. Do not copy, distribute, or reuse without written permission from ReapFX.
